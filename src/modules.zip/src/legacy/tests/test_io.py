#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pytest 

# Internal imports
from constants import io

# from unit import *
# from src.modules import io
# from calculate_kmer_frequencies import getKmerFreqPerRecord, getKmerProp

#------------------- Constants ------------------------------#




#------------------- Public Classes & Functions -------------#

def test_mock():
    print("Hello World")
    print(io.THIS_FILE)

# def test_big_fasta():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_big_fasta_gz():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_small_fasta():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_small_fasta_gz():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# #------------------------------------------------------------#

# def test_big_fastq():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_big_fastq_gz():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_small_fastq():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

# def test_small_fastq_gz():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

#------------------------------------------------------------#

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
