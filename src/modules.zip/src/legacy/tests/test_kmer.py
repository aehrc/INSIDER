#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pytest

# Internal imports
from ..kmer import count

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def test_kmer_seq():
    assert(len(list(count.getKmerSequences(1))) == 4 ** 1)
    assert(len(list(count.getKmerSequences(3))) == 4 ** 3)
    assert(len(list(count.getKmerSequences(5))) == 4 ** 5)

    with pytest.raises(ValueError):
        count.getKmerSequences(-000.1)
        count.getKmerSequences(-1)
        count.getKmerSequences(0)
        count.getKmerSequences(000.1)

def test_count_kmerlength():
    seq  = 'ATCGATATAGC'
    assert(count.countByKmerLength(seq, 1)['A'] == 4)
    assert(count.countByKmerLength(seq, 1)['G'] == 2)
    assert(count.countByKmerLength(seq, 2)['AT'] == 3)
    assert('CA' not in count.countByKmerLength(seq, 2))
    assert('TG' not in count.countByKmerLength(seq, 2))

# def test_kmer_freq():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

#     seqRecords = r.seqRecords
#     kmerFreq = getKmerFreqPerRecord(seqRecords, 1)[0]
#     assert (kmerFreq[FREQUENCY_LABEL][0] == 90407)  # C
#     assert (kmerFreq[FREQUENCY_LABEL][1] == 90407)  # G
#     assert (kmerFreq[FREQUENCY_LABEL][2] == 139811) # A
#     assert (kmerFreq[FREQUENCY_LABEL][3] == 139811) # T

# def test_kmer_prop():
#     r = io.FastaReader(FA_GZ_FILE_1)
#     r.parse()

#     seqRecords = r.seqRecords
#     kmerFreqPerRecord = getKmerFreqPerRecord(seqRecords, 1)
#     kmerFreq          = getKmerProp(kmerFreqPerRecord, seqRecords, True)
#     assert(kmerFreq[PROPORTION_LABEL][0] == 19.635085006385253)
#     assert(kmerFreq[PROPORTION_LABEL][1] == 19.635085006385253)
#     assert(kmerFreq[PROPORTION_LABEL][2] == 30.36491499361475)
#     assert(kmerFreq[PROPORTION_LABEL][3] == 30.36491499361475)

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
