#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports

# External imports
import pytest

# Internal imports
from unit import *
from src.modules import io
from calculate_kmer_frequencies import getKmerFreqPerRecord, getKmerProp

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def test_kmer_freq():
    r = io.FastaReader(FA_GZ_FILE_1)
    r.parse()

    seqRecords = r.seqRecords
    kmerFreq = getKmerFreqPerRecord(seqRecords, 1)[0]
    assert (kmerFreq[FREQUENCY_LABEL][0] == 90407)  # C
    assert (kmerFreq[FREQUENCY_LABEL][1] == 90407)  # G
    assert (kmerFreq[FREQUENCY_LABEL][2] == 139811) # A
    assert (kmerFreq[FREQUENCY_LABEL][3] == 139811) # T

def test_kmer_prop():
    r = io.FastaReader(FA_GZ_FILE_1)
    r.parse()

    seqRecords = r.seqRecords
    kmerFreqPerRecord = getKmerFreqPerRecord(seqRecords, 1)
    kmerFreq          = getKmerProp(kmerFreqPerRecord, seqRecords, True)
    assert(kmerFreq[PROPORTION_LABEL][0] == 19.635085006385253)
    assert(kmerFreq[PROPORTION_LABEL][1] == 19.635085006385253)
    assert(kmerFreq[PROPORTION_LABEL][2] == 30.36491499361475)
    assert(kmerFreq[PROPORTION_LABEL][3] == 30.36491499361475)

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
