#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
import math
import re

# External imports
import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql.window import Window
from pyspark.sql import SparkSession

# Internal imports
from ..common import *

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def getBaseVariants(kmerDf, stranded):
    if (stranded):
        print("Stranded variants")
        ## If we're dealing with double-stranded sequences, then
        ## we would've collapsed complementary Kmers. However, we're
        ## only interested in the first K-mer, so just focus on those.
        f  = F.split(KMER_COL_NAME, '-').getItem(0)
        df = kmerDf.select(SEQID_COL_NAME, f.alias(KMER_COL_NAME))
        raise NotImplementedError('Not implemented properly')

    else:
        print("Unstranded variants")
        kmerDf = kmerDf.select(SEQID_COL_NAME, KMER_COL_NAME)
        vDf = _addFXColumns(kmerDf)

        ## Step 3: Remove K-mers in each genome that result in a SNP conflict
        vDf = _removeCentralBaseVariantKmers(vDf)
        if (len(vDf.head(1)) == 0):
            return None

        ## Step 5 & 6: Look for central base variants across all sequences
        vDf = _getSnpLoci(vDf)
        if (len(vDf.head(1)) == 0):
            return None

        ## Select the columns we want
        vDf = vDf.select(SEQID_COL_NAME, KMER_COL_NAME, 'variants')
        vDf = vDf.coalesce(kmerDf.rdd.getNumPartitions())

    return vDf

def getPositions(vDf, seqDf):
    print("SNP detection")
    snpDf = vDf.join(seqDf, on=SEQID_COL_NAME, how='left')

    ## Step 7 & 8: Find the SNP positions in each sequence and
    ## create the SNP matrix
    snpDf = _addKmerPositionColumn(snpDf)
    snpDf.persist()
    snpDf = _addCentralBaseAbsolutePositionColumn(snpDf)
    snpDf = _addCentralBaseRelativePositionColumn(snpDf)

    ## SNP positions are based on the position of the Kmer in each sequence.
    ## Because of this, we cannot directly compare SNPs across sequences.
    ## Therefore, in addition to the absolute SNP position, we calculate
    ## the relative SNP position which gives us an idea of how SNPs across
    ## each sequence are related.
    snpDf = snpDf.select(SEQID_COL_NAME, 'base', 'pos', 'meanPos')
    return snpDf

#------------------- Private Classes & Functions ------------#

def _getCentralBaseIdx(df):
    ## Calculate location of the the central base (i.e., the SNP)
    kLen = len(df.select(KMER_COL_NAME).first()[0])
    i   = math.floor(kLen / 2)
    return i

def _addFXColumns(kmerDf):
    ## Add prefix and suffix columns
    i  = _getCentralBaseIdx(kmerDf)
    kmerDf = (
        kmerDf
        .withColumn('pfx', F.col(KMER_COL_NAME).substr(1, i))
        .withColumn('sfx', F.col(KMER_COL_NAME).substr(i + 2, i))
    )
    return kmerDf

def _removeCentralBaseVariantKmers(vDf):
    ## Find central base variants within each sequence
    cols = [SEQID_COL_NAME, 'pfx', 'sfx']
    w    = Window.partitionBy(cols)
    vDf  = vDf.repartition(vDf.rdd.getNumPartitions(), cols)
    vDf  = vDf.withColumn(KMER_COL_NAME, F.collect_set(KMER_COL_NAME).over(w))

    ## Remove Kmers that have MORE THAN 1 variant
    cond = (F.size(KMER_COL_NAME) == 1)
    vDf  = vDf.filter(cond)
    vDf  = vDf.withColumn(KMER_COL_NAME, F.col(KMER_COL_NAME).getItem(0))
    return vDf

def _getSnpLoci(vDf):
    ## Find central base variants across all sequences
    cols = ['pfx', 'sfx']
    w    = Window.partitionBy(cols)
    vDf  = vDf.withColumn('variants', F.collect_set(KMER_COL_NAME).over(w))

    ## Remove Kmers that have ONLY 1 variant
    cond = (F.size('variants') > 1)
    vDf  = vDf.filter(cond)
    return vDf

def _addKmerPositionColumn(snpDf):
    ## Add the start position of each Kmer in each sequence.
    ## Instead of the standard Python 0 base index, we adjust the
    ## index so that its consistent with Spark's 1 base index
    ## Although rare, we might have to account for overlapping Kmers.
    f  = lambda x, y: [int(m.start() + 1) for m in list(re.finditer(x, y))]
    f  = F.udf(f, T.ArrayType(T.IntegerType()))
    snpDf = snpDf.withColumn('kmerPos', F.explode(f(KMER_COL_NAME, 'seq')))
    return snpDf

def _addCentralBaseAbsolutePositionColumn(snpDf):
    ## Add the position of each SNP in each sequence
    i  = _getCentralBaseIdx(snpDf)
    snpDf = (
        snpDf
        .withColumn('base', F.col(KMER_COL_NAME).substr(i + 1, 1))
        .withColumn('pos', F.col('kmerPos') + F.lit(i))
    )
    return snpDf

def _addCentralBaseRelativePositionColumn(snpDf):
    ## Add the surrounding sequence context of each Kmer in each sequence
    ## Assumption being that SNPs appearing in the same sequence context
    ## of different sequences are in the same approximate location
    snpDf = _addKmerContextColumn(snpDf)

    ## Add the mean position of each SNP across all sequences. This is
    ## essentially the relative position of the SNP across all sequences.
    cols  = ['variants', 'kmerContext']
    w     = Window.partitionBy(cols)
    snpDf = snpDf.repartition(snpDf.rdd.getNumPartitions(), cols)
    snpDf = snpDf.withColumn('meanPos', F.mean('pos').over(w))
    return snpDf

def _addKmerContextColumn(snpDf):
    kLen = len(snpDf.select(KMER_COL_NAME).first()[0])

    ## Get the prefix string
    pfxE = F.col('kmerPos') - F.lit(1)
    pfxS = pfxE - F.lit(2)
    pfxS = F.when(pfxS < 1, 1).otherwise(pfxS)
    pfxL = pfxE - pfxS + 1
    pfxL = F.when(pfxL > 3, 3).otherwise(pfxL)

    ## Get the suffix string
    sfxS = F.col('kmerPos') + F.lit(kLen)

    ## Get the kmer Context
    pfx = F.col('seq').substr(pfxS, pfxL)
    sfx = F.col('seq').substr(sfxS, F.lit(3))
    snpDf = snpDf.withColumn('kmerContext', F.concat(pfx, F.lit('_'), sfx))
    return snpDf

def _removeIncompleteSNPs(snpDf):
    ## I suppose the question is how many of these variants will we
    ## actually find since this might be too stringent. If the Kmers are
    ## too short or too long then we'll miss lots of variants.

    ## Count the number of SNPs occuring at each location and
    ## locations that appear in some but not all sequences.
    ## Reason being that the sequence context should remain roughly the same
    ## across sequences, and thus can be used to determine the exact location
    ## of a SNP
    numSeqs = snpDf.select(SEQID_COL_NAME).distinct().count()
    w = Window.partitionBy(['variants', 'kmerContext'])
    snpDf = (
        snpDf
        .withColumn('numSnps', F.count(KMER_COL_NAME).over(w))
        .filter(F.col('numSnps') == numSeqs)
    )
    return snpDf

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------



