#!/bin/python

#------------------- Description & Notes --------------------#

#------------------- Dependencies ---------------------------#

# Standard library imports
from pathlib import Path

# External imports
import pandas as pd

# Internal imports

#------------------- Constants ------------------------------#

#------------------- Public Classes & Functions -------------#

def read(*dirs):
    filepaths = [f for d in dirs for f in Path(d).glob('*.csv')]
    snpDfs    = [pd.read_csv(f, sep='\t') for f in filepaths]
    snpDf     = pd.concat(snpDfs).reset_index(drop=True)
    return snpDf

#------------------- Private Classes & Functions ------------#

#------------------- Main -----------------------------------#

if (__name__ == "__main__"):
    main()

#------------------------------------------------------------------------------
